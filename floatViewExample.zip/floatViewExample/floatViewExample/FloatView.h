//
//  FloatView.h
//  floatViewExample
//
//  Created by lc-macbook pro on 2017/6/9.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kScreenSize   [UIScreen mainScreen].bounds.size

@interface FloatView : UIView
@property (nonatomic, strong) UIImageView *imageView;

@end

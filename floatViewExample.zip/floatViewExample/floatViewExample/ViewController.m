//
//  ViewController.m
//  floatViewExample
//
//  Created by lc-macbook pro on 2017/6/9.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "ViewController.h"

#import "FloatView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    FloatView *view = [[FloatView alloc]initWithFrame:CGRectMake(kScreenWidth-50, kScreenHeight-50, 50, 50)];
    [view addSubview:view.imageView];
    [self.view addSubview:view];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

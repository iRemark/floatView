//
//  FloatView.m
//  floatViewExample
//
//  Created by lc-macbook pro on 2017/6/9.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "FloatView.h"



@implementation FloatView

#pragma mark - lazyload

- (UIImageView *)imageView {
    if (_imageView == nil) {
        _imageView = [[UIImageView alloc]init];
        _imageView.image = [UIImage imageNamed:@"telephone"];
        _imageView.frame = self.bounds;
    }
    return _imageView;
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [touches anyObject];
    //CGPoint pt = [touch locationInView:self.superview];
    CGRect frame = self.frame;
    //在自身视图中的位置
    CGPoint pt = [touch locationInView:self];
    CGPoint anchorPoint = CGPointMake(pt.x/self.bounds.size.width, pt.y/self.bounds.size.height);
    //这是设置的是position也就是center的位置百分比
    //也就是鼠标所在的位置
    self.layer.anchorPoint = anchorPoint;
    self.frame = frame;
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    CGPoint pt = [touch locationInView:self.superview];
    
    self.layer.position = pt;
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [self limitRangeOfView];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self limitRangeOfView];
}



- (void)limitRangeOfView {
    [UIView animateWithDuration:0.3 animations:^{
        
        CGFloat padding = 1;
        CGRect frame = self.frame;
        if (frame.origin.x < padding) {
            frame.origin.x = padding;
        }
        if (frame.origin.y < padding) {
            frame.origin.y = padding;
        }
        if (frame.origin.x > (kScreenWidth-frame.size.height-padding)) {
            frame.origin.x = kScreenWidth-frame.size.width-padding;
        }
        if (frame.origin.y > (kScreenHeight-frame.size.height-padding)) {
            frame.origin.y = kScreenHeight-frame.size.height-padding;
        }
        
        self.frame = frame;
    }];
}

@end

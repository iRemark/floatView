//
//  ViewController.h
//  floatViewExample
//
//  Created by lc-macbook pro on 2017/6/9.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

